"use client"
import React from "react";
// =================== Change image path end ================== //

const Layout = ({ children }) => {
  
  return (
    <>
   

      {children}
    </>
  );
};

export default Layout;
