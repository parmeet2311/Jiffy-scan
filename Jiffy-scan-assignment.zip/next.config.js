/** @type {import('next').NextConfig} */
const path = require('path')
const nextConfig = {};

module.exports = nextConfig
